# Link below could be used to convert from lat & lon (WGS84, transverse mercator) to British National Grid (BNG)
# https://www.movable-type.co.uk/scripts/latlong-os-gridref.html

import os, sys, pandas as pd, xarray as xr

def cleanHds(lst):
    '''Removes unwanted characters from text '''
    chrs = [',',' ',"'","_"]
    ret_txt = [lst.replace(x,'') for x in chrs if x in lst]
    return(ret_txt[0])

def check4duplicates(datafile, cols4check=None):
    ''' Removes duplicates of records in given dataframe'''
    # Columns to use for duplicate checking
    if cols4check == None:
        cols_check = list(datafile) # Use all columns to check for querying duplicate records
    else:
        cols_check = cols4check     # Usen given columns to check for querying duplicate records  

    # Drop duplicate records if found    
    datafile.drop_duplicates(subset=cols_check, keep='first', inplace=True)

    return(datafile)

def get_list_of_files(data_folder,file_ext):
    '''Gets all needed files (ending with same extension in a folder given) into a list holder '''
    fileNames = []
    os.chdir(data_folder)
    [fileNames.append(os.path.join(data_folder,files)) for files in os.listdir(".")if files.endswith(file_ext)]
    return(fileNames)

def save_excel_sheet(df, filepath, sheetname, index=False):
    '''Saves pandas dataframe datafile into  MS Excel'''
    df.to_excel(filepath, sheet_name=sheetname, index=index)

def ReadTextAndExcelFiles(file_to_read, sheetname=0):
    '''Read data either in Ms Excel or flat file (.csv, .txt, .dat) into pandas dataframe '''
    # Get extension of the file
    p,f = os.path.split(file_to_read)
    file_extension = f.split('.')[1]

    #Check for right file input
    file1_category2Read = ['csv','txt','dat']
    file2_category2Read = ['xlsx','xls']
    if file_extension not in file1_category2Read and file_extension not in file2_category2Read:
        print('\nInput file must be text or Excel file')
        sys.exit(1)
    
    # Read in first file
    if file_extension in file1_category2Read:
        try:
            df = pd.read_csv(file_to_read)
            return(df)
        except FileNotFoundError as e:
            print(f'Error:{str(e)}')
            sys.exit(1)
    elif file_extension in file2_category2Read:
        try:
            df = pd.read_excel(file_to_read,sheet_name=sheetname)
            return(df)
        except FileNotFoundError as e:
            print(f'Error:{str(e)}')
            sys.exit(1)        
    else:
        sys.exit(f'Can\'t reaad file:{file4match}')
        

def extractFrom_HadUKGrid(datafilesFolder,siteBNGXCoord, siteBNGYCoord, variableName='tasmin',MOFiles=True):
    '''Performs the extraction of data for given sites from HadUK-GRID data. Site coordiantes must be of BNG ones'''
    list_processed_files = [] # For holding all input grid files files processed
    
    # Headers to reatin and order
    if MOFiles: # For Met Office gridded datafile
        headers_to_retain = ['time_bnds', variableName, 'projection_x_coordinate', 'projection_y_coordinate', 'longitude', 'latitude']
    else: # For CEDA PET datafiles    
        headers_to_retain = ['time_bnds',variableName,'x','y','lat','lon']

    # Get into a list of all grid files to process
    list_ncfiles = get_list_of_files(datafilesFolder,'nc')

    # Iterate thru list of file to process
    for numb, nc_file in enumerate(list_ncfiles,1):
                
        # Open the nc file for reading using xarray lib
        nc_file = xr.open_dataset(nc_file)

        # Get subset of data for lat & lon given
        if MOFiles:
            latlon_subset = nc_file.sel(projection_y_coordinate=siteBNGYCoord, projection_x_coordinate=siteBNGXCoord, method='nearest')
        else:    
            latlon_subset = nc_file.sel(y=siteBNGYCoord, x=siteBNGXCoord, method='nearest')
        
        # Convert subset to dataframe
        subset_df = latlon_subset.to_dataframe()

        # Check for duplicate records based on variable values, remove if found
        subset_df = check4duplicates(subset_df, cols4check=[variableName])

        # Remove redundant headers from file
        subset_df = subset_df[headers_to_retain]

        # Append to lists
        list_processed_files.append(subset_df) # file
        
        # Close instance of open xarray file to clean up memory
        nc_file.close()

    # Merge files into one
    dfs_merged = pd.concat(list_processed_files)

    return(dfs_merged)

def extract_save_site_data(sites_file, HadUK_GRID_folder, output_folder, variable_name,MOffice):
    # Open file with sites as dataframe
    df_sites = ReadTextAndExcelFiles(sites_file)

    # Iterate over the files to read each site and extract its data
    for i, item in enumerate(range(len(df_sites)),1):
        sid      = df_sites.loc[item, 'Site_Name']
        easting  = df_sites.loc[item, 'X_Easting']
        northing = df_sites.loc[item, 'Y_Northing']

        print(f'Extracting data for site {i} of {len(df_sites)}')

        # Define output filename with site id as read from the file
        clean_sid = cleanHds(sid)
        filepath = os.path.join(output_folder, f'{clean_sid}.xlsx')
            
        # Call subroutine to extact data from grids in the folder for site
        site_data = extractFrom_HadUKGrid(HadUK_GRID_folder, easting, northing, variable_name,MOffice)

        # save datafile for the site
        sh = f'{clean_sid}'
        if len(sh) <= 30 :sheetname=sh      # only 30 characters allowed for sheet name in MS Excel, check if it is not more than 30
        if len(sh) >  30 :sheetname=sh[:30] # if more than 30 characters, truncate to 30
        save_excel_sheet(site_data, filepath, sheetname, index=False)

