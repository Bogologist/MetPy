import sub_functions as sf # This python file (sub_functions.py) must be in the same folder as this main_program.py file
import time

time_started = time.time()
print('Processing data','----', 'please wait a moment......\n')

################### I/o files
# File and path of list of sites to extract HadUK-GRID for
sites_file        = r'D:\PhD\Evapotranspiration\Met Office\CEDA\2020\Peat_Sites.xlsx'
# Path to folder where HadUK-GRID files are located 
HadUK_GRID_folder = r'D:\PhD\Evapotranspiration\Met Office\CEDA\2020'
# Folder path where output data for each sites will be saved
output_folder     = r'D:\PhD\Evapotranspiration\Met Office\CEDA\2020\Output_Data'

#################### Variable name of met Office gridded data for extraction:tasmin, tasmax, rainfall or CEDA potential evapotranspiration gridded data:pet
variable_name  = 'pet'
MetOffice_data = False  # True for metoffice data

# Call subroutine to extract the data with all parameters given
sf.extract_save_site_data(sites_file, HadUK_GRID_folder, output_folder, variable_name,MetOffice_data)

print('\nAll done in {:,.2f} mins'.format((time.time() - time_started)/60.0))		
	
